function [ci,cj]=find_interest_points(signal, desired)


ci=32;
cj=32;

end



